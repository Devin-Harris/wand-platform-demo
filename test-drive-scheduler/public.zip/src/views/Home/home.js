import Grid from '@/components/grid'

export default {
  name: 'home',
  components: {
    Grid
  }
}