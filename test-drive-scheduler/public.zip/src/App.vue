<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style src="./app.scss" lang="scss"></style>
<script src="./app.js"></script>

