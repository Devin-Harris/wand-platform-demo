<template>
  <div class="cell" @click="$emit('cell-clicked')">
    <div v-if="!cell.isWidget" class="overlay"></div>
    <iframe v-if="cell.isWidget" :src="cell.data"></iframe>
    <img v-else :src="cell.data">
  </div>
</template>

<script src="./cell.js"></script>
<style src="./cell.scss" lang="scss"></style>
