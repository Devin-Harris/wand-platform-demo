export default {
  name: 'cell',
  props: ['cell']
}