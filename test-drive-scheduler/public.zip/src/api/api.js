const base_url = window.location.hostname === 'localhost' ? 'http://localhost:3000' : 'https://wandadvertising.herokuapp.com'

export default base_url